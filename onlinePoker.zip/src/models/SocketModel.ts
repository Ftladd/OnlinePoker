const connectedClients: Record<string, CustomWebSocket> = {};
const connectedClientIds: Record<string, CustomWebSocket> = {};

export { connectedClientIds, connectedClients };
