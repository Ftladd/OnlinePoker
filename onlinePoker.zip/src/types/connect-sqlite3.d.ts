declare module 'connect-sqlite3';
